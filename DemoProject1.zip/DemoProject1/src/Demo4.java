class Table{  
 synchronized void printTable(){//synchronized method  
   /*for(int i=1;i<=5;i++){  
     System.out.println(n*i);  */
     try{  
      Thread.sleep(400);  
     }catch(Exception e){System.out.println ("Thread " + 
             Thread.currentThread().getId() + 
             " is running"); }  
   }  
  
   
}

class Multithreading implements Runnable 
{ 
	Table t; 
	
	Multithreading(Table t){  
		this.t=t;  
		}  
	
    public void run() 
    { 
    	t.printTable();   
    } 
} 

public class Demo4 {

	public static void main(String[] args) {
					
		for (int i=0; i<8; i++) 
        { 
            Thread object = new Thread(new MultithreadingDemo()); 
            object.start(); 
        } 
		
	}
	
}
