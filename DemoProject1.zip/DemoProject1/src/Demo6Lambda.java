
interface FuncInterface 
{ 
    // An abstract function 
    int abstractFun(int x, int y); 
  
    // A non-abstract (or default) function 
    default void normalFun() 
    { 
       System.out.println("Hello"); 
    } 
}

public class Demo6Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FuncInterface fobj2 = (int x, int y)->{int a = x+y; return a;}; 
		FuncInterface fobj3 = (int x, int y)->x-y; 
		FuncInterface fobj4 = (int x, int y)->x*y; 
		  
        // This calls above lambda expression and prints 10. 
        System.out.println("Addition="+fobj2.abstractFun(5,2));
        System.out.println("Substraction="+fobj3.abstractFun(5,3));
        System.out.println("Multiplication="+fobj4.abstractFun(5,4));
		
	}

}
