import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Demo9StremAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> myList = new ArrayList<>();
		for(int i=0; i<100; i++) myList.add(i);
		
		/*
		 * //sequential stream Stream<Integer> sequentialStream = myList.stream();
		 * 
		 * //parallel stream Stream<Integer> parallelStream = myList.parallelStream();
		 * 
		 * //using lambda with Stream API, filter example Stream<Integer> highNums =
		 * parallelStream.filter(p -> p > 90); //using lambda in forEach
		 * highNums.forEach(p -> System.out.print(p+" "));
		 * 
		 * System.out.println();
		 * 
		 * Stream<Integer> highNumsSeq = sequentialStream.filter(p -> p > 90);
		 * highNumsSeq.forEach(p -> System.out.print(p+" "));
		 */
		
	
		List<Integer> number1 = Arrays.asList(2,3,4,5,1,6); 
		  
	    // demonstration of map method 
	    List<Integer> square1 = number1.stream().map(x -> x*x). 
	                           collect(Collectors.toList()); 
	    System.out.println(square1); 
	    
	    number1.stream().map(x-> x*x).forEach(y -> System.out.print(y+" "));
	    
	    System.out.println();
	    
	    List<Integer> ss = number1.stream().sorted().collect(Collectors.toList());
	    System.out.println(ss);
	    
	    
	    List<String> names = 
                Arrays.asList("Reflection","Collection","Stream"); 
  
	    // demonstration of filter method 
	    List<String> result = names.stream().filter(s->s.startsWith("S")). 
	                          collect(Collectors.toList()); 
	    System.out.println(result); 
	    
	    int even = 
	    	       number1.stream().filter(x->x%2==0).reduce(0,(ans,i)-> ans+i); 
	    	  
	    	    System.out.println(even);
	    
	}

}
