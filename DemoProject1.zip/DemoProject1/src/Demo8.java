

interface XYZ{
	
	  default void dd() { System.out.println("Default Interface method"); }
	 
	
	static void show() 
    { 
        System.out.println("Static Method Executed"); 
    } 
	
	//public void square(int a);
	
}

class ABC{
	{
		System.out.println("Dummy ABC");
	}
	
	static{
		System.out.println("ABC Static");
	}
	
	void demo(){
		System.out.println("ABC Method");
	}
	
}

public class Demo8 implements XYZ{
	
	public void square(int a) 
    { 
        System.out.println(a*a); 
    }
	
	{
		System.out.println("dmmydemo8");
	}
	
	static {
		System.out.println("Static block");
	}

	public static void main(String[] args) {
		
		System.out.println("Main block");
		
		ABC abc = new ABC();
		abc.demo();
		
		Demo8 demo8 = new Demo8();
		/* demo8.square(2); */
		demo8.dd();
		XYZ.show();
	}
	
}
