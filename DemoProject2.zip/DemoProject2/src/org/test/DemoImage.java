package org.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoImage {

	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub

		//Registering the Driver
	      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver ());
	      //Getting the connection
	      String oracleUrl = "jdbc:oracle:thin:@localhost:1521/xe";
	      Connection con = DriverManager.getConnection(oracleUrl, "system", "system");
	      System.out.println("Connected to Oracle database.....");
		
	      //To  add image to database
		
		//  PreparedStatement pstmt = con.prepareStatement("INSERT INTO Demo2(name,image2) VALUES(?,?)"); pstmt.setString(1, "Sample Image LR"); 
		  //Inserting Blob type 
		/*
		 * InputStream in = new FileInputStream(
		 * "D:\\Eclipse\\Workspace\\Workspace_1\\ImagesBlobFile\\AddToDatabase\\Sample1.jpg"
		 * ); pstmt.setBlob(2, in);
		 * 
		 * pstmt.execute(); System.out.println("Record inserted");
		 */
		 
	      
	      //Fetch image from database
	      PreparedStatement pstmtf = con.prepareStatement("Select * from demo2 where name=?"); 
	      pstmtf.setString(1, "Sample Image LR"); 
	      
	      ResultSet rs = pstmtf.executeQuery();
	      
	      while(rs.next()) {
	    	  InputStream inf = rs.getBinaryStream("image2");
			
			  File image = new File(
			  "D:\\Eclipse\\Workspace\\Workspace_1\\ImagesBlobFile\\FromDatabase\\Sample2.jpg"
			  ); FileOutputStream fos = new FileOutputStream(image);
			  
			  byte[] buffer = new byte[1]; while (inf.read(buffer) > 0) {
			  fos.write(buffer); } fos.close();
			 
	    	  System.out.println(inf);
	          
	      }
	      
	      //for blob fetching
		/*
		 * while(rs.next()) { InputStream inf = rs.getBinaryStream("image"); File image
		 * = new File(
		 * "D:\\Eclipse\\Workspace\\Workspace_1\\ImagesBlobFile\\FromDatabase\\Sample1.jpg"
		 * ); FileOutputStream fos = new FileOutputStream(image);
		 * 
		 * byte[] buffer = new byte[1]; while (inf.read(buffer) > 0) {
		 * fos.write(buffer); } fos.close();
		 * 
		 * }
		 */
	      
	      System.out.println("Record fetched");
	}

}
